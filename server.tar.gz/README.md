# Visual Studio Code Robot Framework Intellisense

The main README can be found [here](https://github.com/tomi/vscode-rf-language-server/tree/master/client).
