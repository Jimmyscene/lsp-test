"use strict";
const _ = require("lodash");
const search_tree_1 = require("../search-tree");
const logger_1 = require("../../logger");
const formatters_1 = require("../formatters");
const vscode_languageserver_1 = require("vscode-languageserver");
const VARIABLE_PREFIXES = new Set(["$", "@", "%", "&"]);
/**
 * Get completions for syntax keywords
 *
 * @param textToSearch
 * @param syntaxKeywords
 */
function getSyntaxCompletions(textToSearch, syntaxKeywords) {
    const lowerText = textToSearch.toLowerCase();
    return syntaxKeywords
        .filter(keyword => keyword.toLowerCase().startsWith(lowerText))
        .map(keyword => ({
        label: keyword,
        kind: vscode_languageserver_1.CompletionItemKind.Keyword
    }));
}
exports.getSyntaxCompletions = getSyntaxCompletions;
/**
 *
 * @param textToSearch
 * @param symbols
 * @param localVariables
 */
function getKeywordCompletions(textToSearch, symbols, localVariables) {
    if (_isInVariable(textToSearch)) {
        return getVariableCompletions(textToSearch, symbols.variables, localVariables);
    }
    logger_1.ConsoleLogger.debug(`Searching keywords with ${textToSearch}`);
    return symbols.keywords.findByPrefix(textToSearch)
        .map(keyword => {
        let [insertText, insertTextFormat] = _createKeywordSnippet(keyword);
        const detail = _getKeywordArgs(keyword);
        const documentation = _getKeywordDocumentation(keyword);
        if (textToSearch.includes(" ")) {
            // VSCode completion handles only complete words and not spaces,
            // so everything before the last space needs to be trimmed
            // from the insert text for it to work correctly
            const textBeforeLastSpace = textToSearch.substr(0, textToSearch.lastIndexOf(" ") + 1);
            insertText = _removeFromBeginning(insertText, textBeforeLastSpace);
        }
        return {
            label: keyword.id.name,
            kind: vscode_languageserver_1.CompletionItemKind.Function,
            insertText,
            insertTextFormat,
            detail,
            documentation
        };
    });
}
exports.getKeywordCompletions = getKeywordCompletions;
/**
 *
 * @param textToSearch
 * @param globalVariables
 * @param localVariables
 */
function getVariableCompletions(textToSearch, globalVariables, localVariables = search_tree_1.VariableContainer.Empty, suiteVariables = search_tree_1.VariableContainer.Empty) {
    if (!_isInVariable(textToSearch)) {
        return [];
    }
    const searchText = _getVariableSearchText(textToSearch);
    logger_1.ConsoleLogger.debug(`Searching variables with ${searchText}`);
    const localCompletions = localVariables
        .findByPrefix(searchText)
        .map(_localVarToCompletionItem);
    const suiteCompletions = suiteVariables
        .findByPrefix(searchText)
        .map(_suiteVarToCompletionItem);
    const globalCompletions = globalVariables
        .findByPrefix(searchText)
        .map(_globalVarToCompletionItem);
    return [
        ...localCompletions,
        ...suiteCompletions,
        ...globalCompletions
    ];
}
exports.getVariableCompletions = getVariableCompletions;
const _localVarToCompletionItem = variable => _variableToCompletionItem(`0-${variable.id.name}`, variable);
const _suiteVarToCompletionItem = variable => _variableToCompletionItem(`1-${variable.id.name}`, variable);
const _globalVarToCompletionItem = variable => _variableToCompletionItem(`2-${variable.id.name}`, variable);
function _variableToCompletionItem(sortText, variable) {
    const variableLabel = formatters_1.formatVariable(variable);
    const variableName = variable.id.name;
    return {
        label: variableLabel,
        insertText: variableName,
        kind: vscode_languageserver_1.CompletionItemKind.Variable,
        sortText
    };
}
function _isInVariable(text) {
    const lastStartingCurlyIdx = text.lastIndexOf("{");
    if (lastStartingCurlyIdx < 0) {
        return false;
    }
    const lastEndingCurlyIdx = text.lastIndexOf("}");
    if (lastStartingCurlyIdx < lastEndingCurlyIdx) {
        return false;
    }
    const charBeforeCurly = text[lastStartingCurlyIdx - 1];
    if (!VARIABLE_PREFIXES.has(charBeforeCurly)) {
        return false;
    }
    return true;
}
function _getVariableSearchText(textBefore) {
    const curlyBeforeIdx = textBefore.lastIndexOf("{");
    return textBefore.substring(curlyBeforeIdx - 1);
}
/**
 * Creates a signature from given keyword. If the keyword has arguments,
 * the signature is returned as a snippet
 *
 * @param keyword
 */
function _createKeywordSnippet(keyword) {
    if (keyword.arguments) {
        const args = keyword.arguments.values
            .map((arg, idx) => `\${${idx + 1}:${arg.id.name}}`)
            .join("  ");
        return [`${keyword.id.name}  ${args}`, vscode_languageserver_1.InsertTextFormat.Snippet];
    }
    else {
        return [keyword.id.name, vscode_languageserver_1.InsertTextFormat.PlainText];
    }
}
function _removeFromBeginning(toCheck, partToRemove) {
    const regex = new RegExp(`^${_.escapeRegExp(partToRemove)}`, "i");
    return toCheck.replace(regex, "");
}
function _getKeywordArgs(keyword) {
    if (keyword.arguments) {
        return keyword.arguments.values
            .map(arg => formatters_1.formatVariable(arg))
            .join("  ");
    }
    else {
        return undefined;
    }
}
function _getKeywordDocumentation(keyword) {
    if (keyword.documentation && keyword.documentation.value) {
        return keyword.documentation.value.value;
    }
    else {
        return undefined;
    }
}
//# sourceMappingURL=completion-helper.js.map