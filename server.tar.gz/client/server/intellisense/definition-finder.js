"use strict";
const _ = require("lodash");
const logger_1 = require("../logger");
const traverse_1 = require("../traverse/traverse");
const keyword_matcher_1 = require("./keyword-matcher");
const node_locator_1 = require("./node-locator");
const position_1 = require("../utils/position");
const type_guards_1 = require("./type-guards");
const logger = logger_1.ConsoleLogger;
function findDefinition(location, workspaceTree) {
    const file = workspaceTree.getFile(location.filePath);
    if (!file) {
        logger.info(`Definition not found. File '${location.filePath}' not parsed`);
        return null;
    }
    const nodeInPos = node_locator_1.findNodeInPos(location.position, file);
    if (!type_guards_1.isIdentifier(nodeInPos.node)) {
        const logMsg = "Definition not found. " +
            `Node in position is not an identifier, but of type ${nodeInPos.node.type}`;
        logger.info(logMsg);
        return null;
    }
    const parentOfNode = _.last(nodeInPos.path);
    let foundDefinition = null;
    if (type_guards_1.isVariableExpression(parentOfNode)) {
        logger.info("Parent is a variable expression, finding a variable definition");
        foundDefinition = findVariableDefinition(parentOfNode, nodeInPos, workspaceTree);
    }
    else if (type_guards_1.isCallExpression(parentOfNode)) {
        logger.info("Parent is a call expression, finding a keyword definition");
        foundDefinition = findKeywordDefinition(parentOfNode, nodeInPos, workspaceTree);
    }
    else {
        logger.info(`Parent is of type ${parentOfNode.type}. No definition available`);
    }
    return foundDefinition;
}
exports.findDefinition = findDefinition;
function findVariableDefinition(variable, variableLocation, workspaceTree) {
    let foundVariableDefinition = tryFindVarDefStartingFromNode(variable, variableLocation);
    if (foundVariableDefinition) {
        return {
            node: foundVariableDefinition,
            uri: variableLocation.file.uri,
            range: position_1.nodeLocationToRange(foundVariableDefinition)
        };
    }
    // TODO: iterate in import order
    for (const file of workspaceTree.getFiles()) {
        foundVariableDefinition = findVariableDefinitionFromFile(variable, file.ast);
        if (foundVariableDefinition) {
            return {
                node: foundVariableDefinition,
                uri: file.uri,
                range: position_1.nodeLocationToRange(foundVariableDefinition)
            };
        }
    }
    logger.info("Variable definition not found from the workspace");
    return null;
}
exports.findVariableDefinition = findVariableDefinition;
function findKeywordDefinition(callExpression, keywordLocation, workspaceTree) {
    const identifier = callExpression.callee;
    let foundDefinition = findKeywordDefinitionFromFile(callExpression, keywordLocation.file.ast);
    if (foundDefinition) {
        return {
            node: foundDefinition,
            uri: keywordLocation.file.uri,
            range: position_1.nodeLocationToRange(foundDefinition)
        };
    }
    // TODO: iterate in import order
    for (const file of workspaceTree.getFiles()) {
        if (file.filePath === keywordLocation.file.filePath) {
            continue;
        }
        foundDefinition = findKeywordDefinitionFromFile(callExpression, file.ast);
        if (foundDefinition) {
            return {
                node: foundDefinition,
                uri: file.uri,
                range: position_1.nodeLocationToRange(foundDefinition)
            };
        }
    }
    logger.info("Keyword definition not found from the workspace");
    return null;
}
exports.findKeywordDefinition = findKeywordDefinition;
function tryFindVarDefStartingFromNode(variable, location) {
    let foundVariableDefinition = null;
    _.reverse(location.path).find(node => {
        if (!type_guards_1.isFunctionDeclaration(node)) {
            return false;
        }
        // Try to find from steps
        const foundInSteps = node.steps.find(nodeInStep => {
            const { body } = nodeInStep;
            if (type_guards_1.isVariableDeclaration(body) &&
                body.kind === variable.kind &&
                body.id.name === variable.id.name) {
                foundVariableDefinition = body;
                return true;
            }
            else {
                return false;
            }
        }) !== undefined;
        if (foundInSteps) {
            return true;
        }
        if (!type_guards_1.isUserKeyword(node) || !node.arguments) {
            return false;
        }
        // Try to find from keyword arguments
        return node.arguments.values.find(arg => {
            if (arg.kind === variable.kind &&
                arg.id.name === variable.id.name) {
                foundVariableDefinition = arg;
                return true;
            }
            else {
                return false;
            }
        }) !== undefined;
    });
    if (foundVariableDefinition) {
        return foundVariableDefinition;
    }
    if (location.file.ast.variablesTable) {
        location.file.ast.variablesTable.variables.find(varTableVar => {
            if (varTableVar.kind === variable.kind &&
                varTableVar.id.name === variable.id.name) {
                foundVariableDefinition = varTableVar;
                return true;
            }
            else {
                return false;
            }
        });
    }
    return foundVariableDefinition;
}
function findVariableDefinitionFromFile(variable, file) {
    const nodesToEnter = new Set([
        "TestSuite", "VariablesTable"
    ]);
    let foundVariable = null;
    const isNodeSearchedVar = node => type_guards_1.isVariableDeclaration(node) &&
        node.kind === variable.kind &&
        node.id.name === variable.id.name;
    traverse_1.traverse(file, {
        enter: (node, parent) => {
            if (isNodeSearchedVar(node)) {
                foundVariable = node;
                return traverse_1.VisitorOption.Break;
            }
            else if (!nodesToEnter.has(node.type)) {
                return traverse_1.VisitorOption.Skip;
            }
        }
    });
    return foundVariable;
}
function findKeywordDefinitionFromFile(callExpression, file) {
    const nodesToEnter = new Set([
        "TestSuite", "KeywordsTable"
    ]);
    let foundKeyword = null;
    const isNodeSearchedKeyword = node => type_guards_1.isUserKeyword(node) &&
        keyword_matcher_1.identifierMatchesKeyword(callExpression.callee, node);
    traverse_1.traverse(file, {
        enter: (node, parent) => {
            if (isNodeSearchedKeyword(node)) {
                foundKeyword = node;
                return traverse_1.VisitorOption.Break;
            }
            else if (!nodesToEnter.has(node.type)) {
                return traverse_1.VisitorOption.Skip;
            }
        }
    });
    return foundKeyword;
}
//# sourceMappingURL=definition-finder.js.map