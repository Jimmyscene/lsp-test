"use strict";
const parser_1 = require("../../parser/parser");
const workspace_file_1 = require("./workspace-file");
const robotParser = new parser_1.FileParser();
class RobotFile extends workspace_file_1.default {
    constructor(
        // Absolute path of the file in the file system
        filePath, 
        // File's relative path to workspace root
        relativePath, 
        // AST of the file
        fileAst, 
        // Tables read from the robot file
        tables) {
        super(filePath, relativePath, fileAst);
        this.tables = tables;
    }
}
exports.RobotFile = RobotFile;
/**
 * Parses a robot file
 *
 * @param absolutePath
 * @param relativePath
 * @param contents
 */
function createRobotFile(contents, absolutePath, relativePath) {
    const tables = robotParser.readTables(contents);
    const ast = robotParser.parseFile(tables);
    return new RobotFile(absolutePath, relativePath, ast, tables);
}
exports.createRobotFile = createRobotFile;
//# sourceMappingURL=robot-file.js.map