"use strict";
const _ = require("lodash");
const position_helper_1 = require("./position-helper");
const models_1 = require("./models");
const VARIABLE_KINDS = new Map([
    ["$", "Scalar"],
    ["@", "List"],
    ["&", "Dictionary"],
    ["%", "Environment"]
]);
function getTemplateElement(parseResult, cell) {
    const { value, start, end } = parseResult;
    const loc = position_helper_1.location(cell.location.start.line, cell.location.start.column + start, cell.location.start.line, cell.location.start.column + end);
    return new models_1.TemplateElement(value, loc);
}
function getVariableExpression(parseResult, cell) {
    const { type, name, start, end } = parseResult;
    return new models_1.VariableExpression(new models_1.Identifier(name, position_helper_1.location(cell.location.start.line, cell.location.start.column + start + 2, cell.location.start.line, cell.location.start.column + end - 1)), VARIABLE_KINDS.get(type), position_helper_1.location(cell.location.start.line, cell.location.start.column + start, cell.location.start.line, cell.location.start.column + end));
}
function getTemplateLiteral(parseResult, cell) {
    const [quasisParts, expressionParts] = _.partition(parseResult, r => r.kind === "string");
    const quasis = quasisParts.map(part => getTemplateElement(part, cell));
    const expressions = expressionParts.map(part => getVariableExpression(part, cell));
    return new models_1.TemplateLiteral(quasis, expressions, cell.location);
}
function parseVariableString(stringToParse) {
    const typeAndNameRegex = /([$,@,%,&]){([^}]+)}/g;
    let parts = [];
    let index = 0;
    let match = typeAndNameRegex.exec(stringToParse);
    while (match) {
        if (index < match.index) {
            parts.push({
                name: null,
                type: null,
                start: index,
                end: match.index,
                kind: "string",
                value: stringToParse.substring(index, match.index),
            });
        }
        const [matchedStr, type, name] = match;
        parts.push({
            name,
            type,
            value: matchedStr,
            start: match.index,
            end: typeAndNameRegex.lastIndex,
            kind: "var",
        });
        index = typeAndNameRegex.lastIndex;
        match = typeAndNameRegex.exec(stringToParse);
    }
    if (index < stringToParse.length) {
        parts.push({
            name: null,
            type: null,
            start: index,
            end: stringToParse.length,
            kind: "string",
            value: stringToParse.substring(index, stringToParse.length),
        });
    }
    return parts;
}
exports.parseVariableString = parseVariableString;
function parseIdentifier(cell) {
    return new models_1.Identifier(cell.content, cell.location);
}
exports.parseIdentifier = parseIdentifier;
function parseValueExpression(cell) {
    if (!cell) {
        return null;
    }
    const parseResult = parseVariableString(cell.content);
    if (_.isEmpty(parseResult)) {
        return new models_1.Literal("", cell.location);
    }
    else if (parseResult.length === 1) {
        // Literal or VariableExpression
        const result = _.head(parseResult);
        if (result.kind === "var") {
            return getVariableExpression(result, cell);
        }
        else {
            return new models_1.Literal(result.value, cell.location);
        }
    }
    else {
        // Template literal
        return getTemplateLiteral(parseResult, cell);
    }
}
exports.parseValueExpression = parseValueExpression;
function parseCallExpression(cells) {
    if (cells.length === 0) {
        return null;
    }
    const firstCell = _.first(cells);
    const lastCell = _.last(cells);
    const callee = parseIdentifier(firstCell);
    const args = _.drop(cells, 1).map(parseValueExpression);
    return new models_1.CallExpression(callee, args, {
        start: firstCell.location.start,
        end: lastCell.location.end,
    });
}
exports.parseCallExpression = parseCallExpression;
//# sourceMappingURL=primitive-parsers.js.map