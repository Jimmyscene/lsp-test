"use strict";
const _ = require("lodash");
const table_models_1 = require("../table-models");
function position(line, column) {
    return {
        line,
        column
    };
}
exports.position = position;
function location(startLine, startColumn, endLine, endColumn) {
    if (_.isObject(startLine) && _.isObject(startColumn)) {
        return {
            start: startLine,
            end: startColumn
        };
    }
    return {
        start: { line: startLine, column: startColumn },
        end: { line: endLine, column: endColumn },
    };
}
exports.location = location;
function table(name, content) {
    const table = new table_models_1.DataTable(name, content.header);
    return content.rows ? Object.assign(table, { rows: content.rows }) : table;
}
exports.table = table;
function row(location, cells) {
    const row = new table_models_1.DataRow(location);
    return cells ? Object.assign(row, { cells }) : row;
}
exports.row = row;
function cell(location, content) {
    return new table_models_1.DataCell(content, location);
}
exports.cell = cell;
//# sourceMappingURL=test-helper.js.map