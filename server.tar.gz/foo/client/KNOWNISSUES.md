# Known Issues

* Test case templates are not parsed correctly
* For loops are not parsed correctly
* Can't find keywords defined in java libraries
* No definition is available for standard library keywords
* Gherkin style is not yet supported
