"use strict";
const Trie = require("node-ternary-search-trie");
class SymbolContainer {
    constructor() {
        this.tree = new Trie();
    }
    add(item) {
        const normalizedKey = this._getNormalizedKey(item);
        this.tree.set(normalizedKey, item);
    }
    remove(item) {
        const normalizedKey = this._getNormalizedKey(item);
        this.tree.del(normalizedKey);
    }
    forEach(cb) {
        this.tree.traverse((...args) => {
            cb(...args);
        });
    }
    filter(cb) {
        const filtered = [];
        this.forEach((key, item) => {
            if (cb(item)) {
                filtered.push(item);
            }
        });
        return filtered;
    }
    findByPrefix(prefix) {
        const found = [];
        const normalizedPrefix = this._normalizeKey(prefix);
        this.tree.searchWithPrefix(normalizedPrefix, (key, keyword) => {
            found.push(keyword);
        });
        return found;
    }
    copyFrom(other) {
        other.forEach((key, item) => this.tree.set(key, item));
    }
    size() {
        return this.tree.size();
    }
    _getNormalizedKey(item) {
        const key = this.getKey(item);
        return key.toLowerCase();
    }
    _normalizeKey(key) {
        return key.toLowerCase();
    }
}
/**
 * Container for keywords
 */
class KeywordContainer extends SymbolContainer {
    getKey(item) {
        return item.id.name;
    }
}
exports.KeywordContainer = KeywordContainer;
/**
 * Container for variables
 */
class VariableContainer extends SymbolContainer {
    findVariable(kind, name) {
        const matches = this.findByPrefix(name);
        if (matches.length === 0) {
            return null;
        }
        const possibleMatch = matches[0];
        return possibleMatch.kind === kind ? possibleMatch : null;
    }
    getKey(item) {
        return this._getVariableName(item);
    }
    _getVariableName(node) {
        const typeIdentifier = this._variableKindToIdentifier(node.kind);
        if (!typeIdentifier) {
            return node.id.name;
        }
        else {
            return `${typeIdentifier}{${node.id.name}}`;
        }
    }
    // TODO: Move to formatters
    _variableKindToIdentifier(kind) {
        switch (kind) {
            case "Scalar": return "$";
            case "List": return "@";
            case "Dictionary": return "&";
            default: return null;
        }
    }
}
VariableContainer.Empty = new VariableContainer();
exports.VariableContainer = VariableContainer;
;
/**
 * Creates search trees for keywords and variables
 *
 * @param ast
 */
function createFileSearchTrees(ast) {
    const keywords = new KeywordContainer();
    const variables = new VariableContainer();
    if (ast && ast.keywordsTable) {
        ast.keywordsTable.keywords.forEach(keyword => {
            keywords.add(keyword);
        });
    }
    if (ast && ast.variablesTable) {
        ast.variablesTable.variables.forEach(variable => {
            variables.add(variable);
        });
    }
    return {
        keywords,
        variables
    };
}
exports.createFileSearchTrees = createFileSearchTrees;
/**
 * Removes keywords and variables in given fileTree from given search trees
 *
 * @param searchTrees
 * @param ast
 */
function removeFileSymbols(symbols, ast) {
    // TODO: Could use another search trees instead of fileTree
    const { keywords, variables } = symbols;
    if (ast && ast.keywordsTable) {
        ast.keywordsTable.keywords.forEach(keyword => {
            keywords.remove(keyword);
        });
    }
    if (ast && ast.variablesTable) {
        ast.variablesTable.variables.forEach(variable => {
            variables.remove(variable);
        });
    }
}
exports.removeFileSymbols = removeFileSymbols;
//# sourceMappingURL=search-tree.js.map