"use strict";
const workspace_file_1 = require("./workspace-file");
const python_parser_1 = require("../../python-parser/python-parser");
const pythonParser = new python_parser_1.PythonParser();
class PythonFile extends workspace_file_1.default {
    constructor(
        // Absolute path of the file in the file system
        filePath, 
        // File's relative path to workspace root
        relativePath, 
        // AST of the file
        fileTree) {
        super(filePath, relativePath, fileTree);
    }
}
exports.PythonFile = PythonFile;
/**
 * Parses a python file
 *
 * @param absolutePath
 * @param relativePath
 * @param contents
 */
function createPythonFile(contents, absolutePath, relativePath) {
    const ast = pythonParser.parseFile(contents);
    return new PythonFile(absolutePath, relativePath, ast);
}
exports.createPythonFile = createPythonFile;
//# sourceMappingURL=python-file.js.map