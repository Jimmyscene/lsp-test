"use strict";
const search_tree_1 = require("../search-tree");
const vscode_uri_1 = require("vscode-uri");
class WorkspaceFile {
    constructor(
        // Absolute path of the file in the file system
        filePath, 
        // File's relative path to workspace root
        relativePath, 
        // AST of the file
        ast) {
        this.filePath = filePath;
        this.relativePath = relativePath;
        this.ast = ast;
        const { keywords, variables } = search_tree_1.createFileSearchTrees(ast);
        this.keywords = keywords;
        this.variables = variables;
    }
    get uri() {
        return vscode_uri_1.default.file(this.filePath).toString();
    }
}
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = WorkspaceFile;
//# sourceMappingURL=workspace-file.js.map