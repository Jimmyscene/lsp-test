"use strict";
const search_tree_1 = require("../search-tree");
/**
 * A class that represents a workspace (=folder) open in VSCode
 */
class Workspace {
    constructor() {
        // A tree of all global keywords in the workspace
        this.keywords = new search_tree_1.KeywordContainer();
        // A tree of all global variables in the workspace
        this.variables = new search_tree_1.VariableContainer();
        // Mapping from filename: string -> file
        this.filesByPath = new Map();
    }
    /**
     * Adds a file to the workspace
     *
     * @param file
     */
    addFile(file) {
        // Remove file first so its search tree is removed from global tree
        this.removeFileByPath(file.filePath);
        this.keywords.copyFrom(file.keywords);
        this.variables.copyFrom(file.variables);
        this.filesByPath.set(file.filePath, file);
    }
    /**
     *
     * @param filePath
     */
    removeFileByPath(filePath) {
        const existingFile = this.filesByPath.get(filePath);
        if (existingFile) {
            search_tree_1.removeFileSymbols(this, existingFile.ast);
        }
        this.filesByPath.delete(filePath);
    }
    /**
     * Removes all files
     */
    clear() {
        this.filesByPath = new Map();
        this.keywords = new search_tree_1.KeywordContainer();
        this.variables = new search_tree_1.VariableContainer();
    }
    getFile(filename) {
        return this.filesByPath.get(filename);
    }
    getFiles() {
        return this.filesByPath.values();
    }
}
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Workspace;
//# sourceMappingURL=workspace.js.map