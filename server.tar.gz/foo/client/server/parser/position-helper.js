"use strict";
const _ = require("lodash");
function position(line, column) {
    return {
        line,
        column
    };
}
exports.position = position;
function location(startLine, startColumn, endLine, endColumn) {
    if (_.isObject(startLine) && _.isObject(startColumn)) {
        return {
            start: startLine,
            end: startColumn
        };
    }
    return {
        start: { line: startLine, column: startColumn },
        end: { line: endLine, column: endColumn },
    };
}
exports.location = location;
function locationFromStartEnd(start, end) {
    return {
        start: start.start,
        end: end.end
    };
}
exports.locationFromStartEnd = locationFromStartEnd;
function locationFromPositions(start, end) {
    return { start, end };
}
exports.locationFromPositions = locationFromPositions;
//# sourceMappingURL=position-helper.js.map