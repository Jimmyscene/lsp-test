"use strict";
const chai = require("chai");
const primitive_parsers_1 = require("../primitive-parsers");
const table_models_1 = require("../table-models");
const models_1 = require("../models");
const test_helper_1 = require("./test-helper");
describe("parseValueExpression", () => {
    describe("should parse single literals", () => {
        function shouldParseLiteral(cellContent) {
            const loc = test_helper_1.location(0, 0, 0, cellContent.length);
            const cell = new table_models_1.DataCell(cellContent, loc);
            const parsed = primitive_parsers_1.parseValueExpression(cell);
            const expected = new models_1.Literal(cellContent, loc);
            chai.assert.deepEqual(parsed, expected);
        }
        it("should parse simple literals", () => {
            shouldParseLiteral("Just some text");
            shouldParseLiteral("Another part of text");
        });
    });
    describe("should parse single variable expressions", () => {
        it("should parse scalar variable expressions", () => {
            const expected = new models_1.VariableExpression(new models_1.Identifier("VAR", test_helper_1.location(0, 2, 0, 5)), "Scalar", test_helper_1.location(0, 0, 0, 6));
            const actual = primitive_parsers_1.parseValueExpression(new table_models_1.DataCell("${VAR}", test_helper_1.location(0, 0, 0, 6)));
            chai.assert.deepEqual(actual, expected);
        });
        it("should parse list variable expressions", () => {
            const expected = new models_1.VariableExpression(new models_1.Identifier("VAR", test_helper_1.location(0, 2, 0, 5)), "List", test_helper_1.location(0, 0, 0, 6));
            const actual = primitive_parsers_1.parseValueExpression(new table_models_1.DataCell("@{VAR}", test_helper_1.location(0, 0, 0, 6)));
            chai.assert.deepEqual(actual, expected);
        });
    });
    describe("should parse template literal", () => {
        it("should parse template with multiple expressions", () => {
            const input = "Template ${arg1} with @{arg2} multiple args";
            const loc = test_helper_1.location(0, 0, 0, input.length);
            const cell = new table_models_1.DataCell(input, loc);
            const expected = new models_1.TemplateLiteral([
                new models_1.TemplateElement("Template ", test_helper_1.location(0, 0, 0, 9)),
                new models_1.TemplateElement(" with ", test_helper_1.location(0, 16, 0, 22)),
                new models_1.TemplateElement(" multiple args", test_helper_1.location(0, 29, 0, 43)),
            ], [
                new models_1.VariableExpression(new models_1.Identifier("arg1", test_helper_1.location(0, 11, 0, 15)), "Scalar", test_helper_1.location(0, 9, 0, 16)),
                new models_1.VariableExpression(new models_1.Identifier("arg2", test_helper_1.location(0, 24, 0, 28)), "List", test_helper_1.location(0, 22, 0, 29)),
            ], loc);
            const actual = primitive_parsers_1.parseValueExpression(cell);
            chai.assert.deepEqual(actual, expected);
        });
    });
});
//# sourceMappingURL=primitive-parsers.test.js.map