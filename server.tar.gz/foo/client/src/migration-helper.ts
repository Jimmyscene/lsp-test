import checkPythonKeywords from "./migrations/python-keywords";

export function runMigrations() {
  checkPythonKeywords();
}
