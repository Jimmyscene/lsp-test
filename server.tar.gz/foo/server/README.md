# Robot Framework Intellisense - Language Server

This is a language server implementation
