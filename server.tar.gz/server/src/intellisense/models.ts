import { Range, Location } from "vscode-languageserver";

export type Range = Range;

export type Location = Location;
