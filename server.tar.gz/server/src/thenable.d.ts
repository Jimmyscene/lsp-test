// We need this until the LSP node libraries are on TS 2.x as well.
interface Thenable<T> extends PromiseLike<T> {}
